
interface AnalysisResponse {
  result: string;
  success: boolean;
  error?: string;
}

// Function to encode an image to base64
export async function encodeImageToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        // Remove the data URL prefix (e.g., "data:image/jpeg;base64,")
        const base64String = reader.result.split(',')[1];
        resolve(base64String);
      } else {
        reject(new Error('Failed to convert to base64'));
      }
    };
    reader.onerror = error => reject(error);
  });
}

// Function to analyze image with OpenAI
export async function analyzeImage(imageBase64: string): Promise<AnalysisResponse> {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer 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',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "Você é um assistente especializado em diagnóstico médico por imagem. Analise a imagem fornecida e forneça uma hipótese diagnóstica e recomendação clínica. Seu resultado deve ter apenas dois elementos: uma hipótese diagnóstica e uma recomendação de conduta. Seja preciso, claro e objetivo."
          },
          {
            role: "user",
            content: [
              { 
                type: "text", 
                text: "Analise esta imagem médica e forneça uma hipótese diagnóstica e recomendação clínica." 
              },
              { 
                type: "image_url", 
                image_url: { 
                  url: `data:image/jpeg;base64,${imageBase64}` 
                } 
              }
            ]
          }
        ],
        max_tokens: 800
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('API error:', errorData);
      return {
        success: false,
        result: '',
        error: `Error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`
      };
    }

    const data = await response.json();
    return {
      success: true,
      result: data.choices[0].message.content
    };
  } catch (error) {
    console.error('Failed to analyze image:', error);
    return {
      success: false,
      result: '',
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}
