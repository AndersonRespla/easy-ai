
import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle2, FileText, Download, ArrowUpRight } from 'lucide-react';

interface DiagnosisResultProps {
  result: string;
  onReset: () => void;
}

const DiagnosisResult: React.FC<DiagnosisResultProps> = ({ result, onReset }) => {
  // Check if the result contains "urgência" or "emergência" to determine severity
  const isUrgent = result.toLowerCase().includes('urgência') || 
                  result.toLowerCase().includes('emergência') ||
                  result.toLowerCase().includes('imediata');

  // Format the result text
  const formatResultText = (text: string) => {
    // Split by line breaks
    const parts = text.split('\n\n');
    
    if (parts.length > 1) {
      return {
        diagnosis: parts[0].replace('Hipótese diagnóstica:', '').trim(),
        recommendation: parts[1].replace('Recomendação de conduta:', '').trim()
      };
    }
    
    return {
      diagnosis: text,
      recommendation: 'Consulte um médico para avaliação completa.'
    };
  };

  const { diagnosis, recommendation } = formatResultText(result);

  const handleDownloadPDF = () => {
    // This would be implemented with a PDF generation library
    alert('Funcionalidade de download de PDF será implementada em breve.');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-2xl p-8 mx-auto rounded-xl glass shadow-lg"
    >
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold text-gray-800">Resultado da Análise</h2>
          <div className={`px-3 py-1 text-sm font-medium rounded-full ${
            isUrgent 
              ? 'bg-red-100 text-red-700' 
              : 'bg-green-100 text-green-700'
          }`}>
            {isUrgent ? (
              <div className="flex items-center gap-1.5">
                <AlertCircle size={14} />
                <span>Atenção requerida</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={14} />
                <span>Sem urgência aparente</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="p-5 space-y-4 bg-white border rounded-lg shadow-sm">
          <div>
            <h3 className="flex items-center gap-2 mb-2 text-lg font-medium text-gray-700">
              <FileText size={18} className="text-medical-blue" />
              Hipótese Diagnóstica
            </h3>
            <p className="text-gray-700">{diagnosis}</p>
          </div>
          
          <div className="w-full h-px bg-gray-200" />
          
          <div>
            <h3 className="flex items-center gap-2 mb-2 text-lg font-medium text-gray-700">
              <CheckCircle2 size={18} className="text-medical-blue" />
              Recomendação
            </h3>
            <p className="text-gray-700">{recommendation}</p>
          </div>
        </div>
        
        <div className="px-4 py-3 text-sm text-blue-800 bg-blue-50 border border-blue-100 rounded-lg">
          <p>Esta análise é gerada por IA e serve apenas como referência inicial. Não substitui o diagnóstico médico profissional.</p>
        </div>
        
        <div className="flex flex-col gap-4 sm:flex-row">
          <button
            onClick={onReset}
            className="flex items-center justify-center flex-1 gap-2 px-4 py-3 font-medium text-gray-700 transition-all bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            Nova análise
          </button>
          
          <button
            onClick={handleDownloadPDF}
            className="flex items-center justify-center flex-1 gap-2 px-4 py-3 font-medium text-white transition-all bg-medical-blue rounded-lg hover:bg-blue-700"
          >
            <Download size={18} />
            Baixar laudo em PDF
          </button>
        </div>
        
        <div className="flex justify-center">
          <a href="#" className="flex items-center gap-1.5 text-sm text-medical-blue hover:underline">
            <span>Consultar um especialista</span>
            <ArrowUpRight size={14} />
          </a>
        </div>
      </div>
    </motion.div>
  );
};

export default DiagnosisResult;
