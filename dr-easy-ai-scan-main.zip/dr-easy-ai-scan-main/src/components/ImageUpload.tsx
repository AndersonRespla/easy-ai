
import React, { useState, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, Image as ImageIcon, FileX, Upload as UploadIcon, Loader2 } from 'lucide-react';
import { encodeImageToBase64, analyzeImage } from '../services/api';

interface ImageUploadProps {
  onAnalysisComplete: (result: string) => void;
  onError: (error: string) => void;
}

const ImageUpload: React.FC<ImageUploadProps> = ({ onAnalysisComplete, onError }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const processFile = useCallback((file: File) => {
    // Check if file is an image
    if (!file.type.match('image.*')) {
      onError('Por favor, envie apenas arquivos de imagem.');
      return;
    }
    
    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      onError('O arquivo é muito grande. O tamanho máximo é 10MB.');
      return;
    }
    
    setFile(file);
    
    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  }, [onError]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  }, [processFile]);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  }, [processFile]);

  const handleUploadClick = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleRemoveFile = useCallback(() => {
    setFile(null);
    setPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, []);

  const handleAnalyzeImage = useCallback(async () => {
    if (!file) {
      onError('Por favor, selecione uma imagem para análise.');
      return;
    }

    setIsLoading(true);
    setUploadProgress(0);

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          const newProgress = prev + Math.random() * 20;
          return newProgress > 90 ? 90 : newProgress;
        });
      }, 300);

      const base64Image = await encodeImageToBase64(file);
      const result = await analyzeImage(base64Image);
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      if (result.success) {
        onAnalysisComplete(result.result);
      } else {
        onError(result.error || 'Ocorreu um erro ao analisar a imagem.');
      }
    } catch (error) {
      onError(error instanceof Error ? error.message : 'Erro desconhecido');
    } finally {
      setIsLoading(false);
    }
  }, [file, onAnalysisComplete, onError]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-2xl p-8 mx-auto rounded-xl glass shadow-lg"
    >
      <div className="space-y-6">
        <h2 className="text-2xl font-semibold text-center text-gray-800">Envie sua imagem para análise</h2>
        
        <div
          className={`dropzone p-8 flex flex-col items-center justify-center cursor-pointer min-h-[300px] ${
            isDragging ? 'dropzone-active' : 'border-gray-300 hover:border-medical-blue'
          } ${preview ? 'bg-gray-50' : 'bg-white'}`}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onClick={!preview ? handleUploadClick : undefined}
        >
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept="image/*"
            onChange={handleFileChange}
          />
          
          {preview ? (
            <div className="relative w-full">
              <div className="relative overflow-hidden rounded-lg shadow-md aspect-video">
                <img 
                  src={preview} 
                  alt="Preview" 
                  className="object-contain w-full h-full"
                />
              </div>
              <button 
                onClick={handleRemoveFile}
                className="absolute p-2 text-red-500 bg-white rounded-full shadow-md top-2 right-2 hover:bg-red-50"
              >
                <FileX size={18} />
              </button>
              <p className="mt-4 text-sm text-center text-gray-500">
                {file?.name} ({Math.round(file?.size / 1024)} KB)
              </p>
            </div>
          ) : (
            <>
              <Upload className="w-16 h-16 mb-4 text-medical-blue animate-pulse-subtle" />
              <p className="mb-2 text-lg font-medium text-gray-700">
                Arraste e solte sua imagem aqui
              </p>
              <p className="text-sm text-gray-500">
                ou clique para selecionar
              </p>
              <p className="mt-4 text-xs text-gray-400">
                Suporta JPG, PNG, GIF (máx. 10MB)
              </p>
            </>
          )}
        </div>
        
        {isLoading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">Processando...</span>
              <span className="text-sm font-medium text-medical-blue">{Math.round(uploadProgress)}%</span>
            </div>
            <div className="w-full h-2 overflow-hidden bg-gray-200 rounded-full">
              <motion.div 
                className="h-full bg-medical-blue"
                initial={{ width: 0 }}
                animate={{ width: `${uploadProgress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>
        )}
        
        <div className="flex flex-col gap-4 sm:flex-row">
          <button
            type="button"
            onClick={handleUploadClick}
            className="flex items-center justify-center flex-1 gap-2 px-4 py-3 text-gray-700 transition-all bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <ImageIcon size={18} />
            <span>Escolher outra imagem</span>
          </button>
          
          <button
            onClick={handleAnalyzeImage}
            disabled={!file || isLoading}
            className={`flex-1 px-4 py-3 flex gap-2 items-center justify-center rounded-lg font-medium transition-all ${
              !file || isLoading
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-medical-blue text-white hover:bg-blue-700'
            }`}
          >
            {isLoading ? (
              <Loader2 size={18} className="animate-spin" />
            ) : (
              <UploadIcon size={18} />
            )}
            <span>{isLoading ? 'Analisando...' : 'Analisar imagem'}</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ImageUpload;
