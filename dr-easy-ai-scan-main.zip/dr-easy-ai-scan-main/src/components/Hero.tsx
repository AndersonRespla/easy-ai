
import React from 'react';
import { motion } from 'framer-motion';

interface HeroProps {
  onGetStarted: () => void;
}

const Hero: React.FC<HeroProps> = ({ onGetStarted }) => {
  return (
    <section className="relative w-full py-20 overflow-hidden bg-gradient-to-b from-medical-light-blue to-white">
      <div className="absolute inset-0 z-0 opacity-40">
        <div className="absolute top-0 left-0 w-64 h-64 bg-medical-blue rounded-full blur-[100px] -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-sky-400 rounded-full blur-[100px] translate-x-1/2 translate-y-1/2" />
      </div>
      
      <div className="container relative z-10 px-4 mx-auto">
        <motion.div 
          className="max-w-3xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="inline-block px-4 py-1.5 mb-6 text-sm font-medium text-medical-blue rounded-full bg-white/80 backdrop-blur border border-blue-100"
          >
            Tecnologia a serviço da saúde
          </motion.div>
          
          <motion.h1 
            className="mb-6 text-4xl font-bold leading-tight tracking-tighter md:text-5xl lg:text-6xl bg-clip-text text-transparent bg-gradient-to-r from-medical-blue to-sky-600"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            Diagnóstico por Imagem com Inteligência e Agilidade
          </motion.h1>
          
          <motion.p 
            className="mb-10 text-lg text-slate-700 md:text-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
          >
            Envie sua imagem e receba uma análise rápida com o apoio da nossa IA + validação médica.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
          >
            <button 
              onClick={onGetStarted}
              className="px-8 py-4 text-lg font-medium text-white transition-all bg-medical-blue rounded-lg shadow-lg hover:bg-blue-700 hover:shadow-xl focus:ring-4 focus:ring-blue-200 focus:outline-none"
            >
              Enviar Imagem
            </button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
