
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from "sonner";
import Hero from '../components/Hero';
import ImageUpload from '../components/ImageUpload';
import DiagnosisResult from '../components/DiagnosisResult';

const Index = () => {
  const [step, setStep] = useState<'hero' | 'upload' | 'result'>('hero');
  const [result, setResult] = useState<string>('');
  const uploadSectionRef = useRef<HTMLDivElement>(null);

  const handleGetStarted = () => {
    setStep('upload');
    // Smooth scroll to upload section
    setTimeout(() => {
      uploadSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleAnalysisComplete = (analysisResult: string) => {
    setResult(analysisResult);
    setStep('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleError = (error: string) => {
    toast.error(error);
  };

  const handleReset = () => {
    setStep('upload');
    setResult('');
  };

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-medical-gray">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full backdrop-blur-lg bg-white/80 border-b border-gray-200">
        <div className="container flex items-center justify-between h-16 px-4 mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-medical-blue rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">D</span>
            </div>
            <h1 className="text-xl font-bold text-gray-900">Dr. Easy AI</h1>
          </div>
          
          <nav className="hidden md:flex items-center gap-6">
            <a href="#" className="text-sm font-medium text-gray-700 hover:text-medical-blue">Como funciona</a>
            <a href="#" className="text-sm font-medium text-gray-700 hover:text-medical-blue">Especialidades</a>
            <a href="#" className="text-sm font-medium text-gray-700 hover:text-medical-blue">Para médicos</a>
            <a href="#" className="text-sm font-medium text-gray-700 hover:text-medical-blue">Contato</a>
          </nav>
          
          <div className="flex items-center gap-3">
            <button className="hidden px-4 py-2 text-sm font-medium text-medical-blue border border-medical-blue rounded-lg md:block hover:bg-medical-light-blue">
              Entrar
            </button>
            <button className="px-4 py-2 text-sm font-medium text-white bg-medical-blue rounded-lg hover:bg-blue-700">
              Cadastrar
            </button>
          </div>
        </div>
      </header>

      <main>
        {/* Step 1: Hero Section (only shown in hero step) */}
        {step === 'hero' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Hero onGetStarted={handleGetStarted} />
          </motion.div>
        )}

        {/* Step 2 & 3: Upload and Result Section */}
        <div 
          ref={uploadSectionRef}
          className={`py-16 px-4 ${step !== 'hero' ? 'min-h-screen' : ''}`}
        >
          <AnimatePresence mode="wait">
            {step === 'upload' && (
              <motion.div
                key="upload"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <ImageUpload 
                  onAnalysisComplete={handleAnalysisComplete} 
                  onError={handleError} 
                />
              </motion.div>
            )}

            {step === 'result' && (
              <motion.div
                key="result"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <DiagnosisResult result={result} onReset={handleReset} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Features Section */}
        {step === 'hero' && (
          <section className="py-20 bg-white">
            <div className="container px-4 mx-auto">
              <div className="max-w-3xl mx-auto mb-16 text-center">
                <h2 className="mb-4 text-3xl font-bold text-gray-900">Como nosso sistema funciona</h2>
                <p className="text-lg text-gray-600">
                  Combinamos inteligência artificial avançada com a expertise de médicos especialistas para fornecer análises preliminares rápidas e confiáveis.
                </p>
              </div>
              
              <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
                {[
                  {
                    step: "01",
                    title: "Envie sua imagem",
                    description: "Faça upload de raio-x, tomografias ou ressonâncias em segundos."
                  },
                  {
                    step: "02",
                    title: "Análise por IA",
                    description: "Nossa IA avançada analisa a imagem e gera um laudo preliminar."
                  },
                  {
                    step: "03",
                    title: "Revisão médica",
                    description: "Especialistas revisam o resultado para garantir a precisão."
                  }
                ].map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                    viewport={{ once: true }}
                    className="p-6 bg-white border rounded-xl shadow-sm"
                  >
                    <div className="flex items-center justify-center w-12 h-12 mb-4 text-white bg-medical-blue rounded-full">
                      {feature.step}
                    </div>
                    <h3 className="mb-3 text-xl font-semibold text-gray-900">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="py-12 bg-gray-100">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-medical-blue rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">D</span>
              </div>
              <h1 className="text-xl font-bold text-gray-900">Dr. Easy AI</h1>
            </div>
            
            <div className="flex flex-wrap gap-6 text-sm text-gray-600">
              <a href="#" className="hover:text-medical-blue">Termos de Uso</a>
              <a href="#" className="hover:text-medical-blue">Política de Privacidade</a>
              <a href="#" className="hover:text-medical-blue">Contato</a>
              <a href="#" className="hover:text-medical-blue">Blog</a>
            </div>
            
            <div className="text-sm text-gray-500">
              © {new Date().getFullYear()} Dr. Easy AI. Todos os direitos reservados.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
